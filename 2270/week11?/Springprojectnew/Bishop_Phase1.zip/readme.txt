Phase 1 of the Spring 2270 project!

Ryan Bishop rybi2980@colorado.edu

Functionality nearly complete, with some issues with fs functions. 

Adding to commit works, removing from commit works.

Commiting doesn't work, fs::exists() on line 79 of miniGit.cpp throws 
an exception I can't fix in time for due date.

checking out a specific version likely has similar errors, though I cannot 
check due to aformentioned bugs.

See you in the grading interview!